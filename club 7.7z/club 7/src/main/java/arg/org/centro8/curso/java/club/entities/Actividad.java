package arg.org.centro8.curso.java.club.entities;

import arg.org.centro8.curso.java.club.enums.Dia;
import arg.org.centro8.curso.java.club.enums.Turno;

public class Actividad {
    
    private int id;
    private String nombre;
    private String entrenador;
    private Dia dia;
    private Turno turno;
    
    public Actividad() {
    }

    public Actividad(String nombre, String entrenador, Dia dia, Turno turno) {
        this.nombre = nombre;
        this.entrenador = entrenador;
        this.dia = dia;
        this.turno = turno;
    }

    public Actividad(int id, String nombre, String entrenador, Dia dia, Turno turno) {
        this.id = id;
        this.nombre = nombre;
        this.entrenador = entrenador;
        this.dia = dia;
        this.turno = turno;
    }

    @Override
    public String toString() {
        return "Actividad [id=" + id + ", nombre=" + nombre + ", entrenador=" + entrenador + ", dia=" + dia + ", turno="
                + turno + "]";
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEntrenador() {
        return entrenador;
    }

    public void setEntrenador(String entrenador) {
        this.entrenador = entrenador;
    }

    public Dia getDia() {
        return dia;
    }

    public void setDia(Dia dia) {
        this.dia = dia;
    }

    public Turno getTurno() {
        return turno;
    }

    public void setTurno(Turno turno) {
        this.turno = turno;
    }
    
    

}